﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GrDes_Guide
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        GuideEntities db = new GuideEntities();

        public Registration()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var Users1 = new Users();

            try
            {
                if (FirstNameTextBox.Text.Length == 0 || LastNameTextBox.Text.Length == 0 || MiddleNameTextBox.Text.Length == 0 || EmailTextBox.Text.Length == 0 || UsernameTextBox.Text.Length == 0 || PasswordBox.Password.Length == 0)
                {
                    MessageBox.Show("Вы заполнили не все поля", "Не удалось зарегистрировать!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else 
                {
                    if (PasswordBox.Password == RepeatPasswordBox.Password)
                    {
                        Users1.name = FirstNameTextBox.Text;
                        Users1.lastname = LastNameTextBox.Text;
                        Users1.surname = MiddleNameTextBox.Text;
                        Users1.email = EmailTextBox.Text;
                        Users1.login = UsernameTextBox.Text;
                        Users1.password = PasswordBox.Password;
                        Users1.role = 1;

                        db.Users.Add(Users1);
                        db.SaveChanges();

                        MessageBox.Show("Вы успешно зарегистрированы!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);

                        MainWindow mainWindow = new MainWindow();
                        mainWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Повторно введённый пароль не соответствует первому", "Не удалось зарегистрировать!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Произошла ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
