﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GrDes_Guide
{
    public partial class Student_main : Window
    {
        GuideEntities db = new GuideEntities();
        private int usID;

        public Student_main(int usID)
        {
            InitializeComponent();
            this.usID = usID;

            var lessons = (from x in db.Lesson select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lessons;

            var user = (from x in db.Users where x.ID == usID select x).ToArray();
            username_text.Text = user[0].login;
            email_text.Text = user[0].email;

            LessonsListBox.Visibility = Visibility.Collapsed;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var lassons = (from x in db.Lesson where x.sections == 1 select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lassons;

            MainContent.Visibility = Visibility.Collapsed;

            LessonsListBox.Visibility = Visibility.Visible;
        }

        private void LessonsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = LessonsListBox.SelectedItem as Lesson;
            var way = (from x in db.Lesson where x.ID == selected.ID select x).ToArray();
            var way1 = way[0].content_file;
            try
            {
                Process.Start(new ProcessStartInfo {
                    FileName = way1,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось открыть файл: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var lassons = (from x in db.Lesson where x.sections == 2 select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lassons;

            MainContent.Visibility = Visibility.Collapsed;

            LessonsListBox.Visibility = Visibility.Visible;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var lassons = (from x in db.Lesson where x.sections == 3 select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lassons;

            MainContent.Visibility = Visibility.Collapsed;

            LessonsListBox.Visibility = Visibility.Visible;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            LessonsListBox.Visibility = Visibility.Collapsed;
            MainContent.Visibility = Visibility.Visible;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Profile_stud profile_Stud = new Profile_stud(usID);
            profile_Stud.Show();
            this.Close();
        }
    }
}
