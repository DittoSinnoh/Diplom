﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GrDes_Guide
{
    /// <summary>
    /// Логика взаимодействия для Test.xaml
    /// </summary>
    public partial class Test : Window
    {
        private int _testId;

        public Test(int testId)
        {
            InitializeComponent();
            _testId = testId;
            LoadTest(_testId);
        }

        private Dictionary<int, int> SelectedAnswers = new Dictionary<int, int>();


        public class TestQuestionViewModel
        {
            public string QuestionText { get; set; }
            public string Group { get; set; }
            public List<TestVariantViewModel> Variants { get; set; }
        }

        public class TestVariantViewModel
        {
            public string VariantText { get; set; }
            public int VariantId { get; set; }
            public string Group { get; set; }
            public bool IsCorrect { get; set; }
        }

        public class TestResultViewModel
        {
            public int ID { get; set; }
            public int ID_test { get; set; }
            public int ID_user { get; set; }
            public int result { get; set; }
        }

        private void LoadTest(int testId)
        {
            using (var db = new GuideEntities())
            {
                var questions = db.Questions
                    .Where(q => q.ID_test == testId)
                    .Select(q => new TestQuestionViewModel
                    {
                        QuestionText = q.question,
                        Group = "Group" + q.ID,
                        Variants = db.Variants
                            .Where(v => v.ID_question == q.ID)
                            .Select(v => new TestVariantViewModel
                            {
                                VariantText = v.variant,
                                VariantId = v.ID,
                                Group = "Group" + q.ID,
                                IsCorrect = v.accuracy == true
                            }).ToList()
                    }).ToList();

                QuestionsList.ItemsSource = questions;
                TestPanel.Visibility = Visibility.Visible;
            }
        }

        List<string> names = new List<string>();

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            var radio = sender as RadioButton;
            if (radio?.Tag is int variantId)
            {
                var question = ((radio.DataContext as TestVariantViewModel)?.Group).Replace("Group", "");
                if (int.TryParse(question, out int questionId))
                {
                    SelectedAnswers[questionId] = variantId;
                }
            }
        }
 
        private int currentUserId = 2;
        private int currentTestId = 1;

        private void SubmitTest_Click(object sender, RoutedEventArgs e)
        {
            ;

            // пример подсчёта — зависит от структуры баллов
            int correctCount = 0;

            foreach (var question in QuestionsList.ItemsSource.Cast<TestQuestionViewModel>())
            {
                var selectedVariant = question.Variants.FirstOrDefault(v => SelectedAnswers.ContainsValue(v.VariantId));
                if (selectedVariant != null && selectedVariant.IsCorrect)
                {
                    correctCount++;
                }
            }

            using (var db = new GuideEntities())
            {
                var results = new Results();
                results.ID_test = currentTestId;
                results.ID_user = currentUserId;
                results.result = correctCount;

                db.Results.Add(results);
                db.SaveChanges();
            }

            MessageBox.Show($"Вы ответили правильно на {correctCount} вопросов из {QuestionsList.Items.Count}.");
        }

    }
}
