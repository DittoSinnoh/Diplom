﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GrDes_Guide
{
    /// <summary>
    /// Логика взаимодействия для Student_main.xaml
    /// </summary>
    public partial class Student_main : Window
    {
        GuideEntities db = new GuideEntities();

        public Student_main()
        {
            InitializeComponent();

            var lessons = (from x in db.Lesson select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lessons;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void LessonsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = LessonsListBox.SelectedItem as Lesson;
            var way = (from x in db.Lesson where x.ID == selected.ID select x).ToArray();
            var way1 = way[0].content_file;
            try
            {
                Process.Start(new ProcessStartInfo {
                    FileName = way1,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось открыть файл: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
