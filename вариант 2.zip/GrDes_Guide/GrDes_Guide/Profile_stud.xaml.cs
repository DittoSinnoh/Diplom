﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GrDes_Guide
{
    /// <summary>
    /// Логика взаимодействия для Profile_stud.xaml
    /// </summary>
    public partial class Profile_stud : Window
    {
        GuideEntities db = new GuideEntities();
        private int usID;

        public Profile_stud(int usID)
        {
            InitializeComponent();
            this.usID = usID;

            var lessons = (from x in db.Lesson select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lessons;

            var user = (from x in db.Users where x.ID == usID select x).ToArray();
            username_text.Text = user[0].login;
            email_text.Text = user[0].email;

            username_text_prof.Text = user[0].login;
            email_text_prof.Text = user[0].email;
            lastname_name_text_prof.Text = user[0].lastname;
            name_text_prof.Text = user[0].name;
            surname_text_prof.Text = user[0].surname;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Student_main student_Main = new Student_main(usID);
            student_Main.Show();
            this.Close();
        }

        private void ShowProfile_Click(object sender, RoutedEventArgs e)
        {
            CoursePanel.Visibility = Visibility.Visible;
            LessonsListBox.Visibility = Visibility.Collapsed;
            MainContent.Visibility = Visibility.Collapsed;
            FileHistoryPanel.Visibility = Visibility.Collapsed;
            Course_Panel.Visibility = Visibility.Visible;
        }

        private void ShowLessons_Click(object sender, RoutedEventArgs e)
        {
            CoursePanel.Visibility = Visibility.Collapsed;
            LessonsListBox.Visibility = Visibility.Collapsed;
            MainContent.Visibility = Visibility.Collapsed;
            FileHistoryPanel.Visibility = Visibility.Visible;
            Course_Panel.Visibility = Visibility.Visible;

            LoadUserResults(usID);
        }

        private void ShowCourse_Click(object sender, RoutedEventArgs e)
        {
            CoursePanel.Visibility = Visibility.Collapsed;
            LessonsListBox.Visibility = Visibility.Collapsed;
            MainContent.Visibility = Visibility.Visible;
            FileHistoryPanel.Visibility = Visibility.Collapsed;
            Course_Panel.Visibility = Visibility.Visible;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var lassons = (from x in db.Lesson where x.sections == 1 select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lassons;

            var tests = (from x in db.Tests where x.section == 1 select x).ToArray();
            TestsListBox.DisplayMemberPath = "title";
            TestsListBox.SelectedValuePath = "ID";
            TestsListBox.ItemsSource = tests;

            Course_Panel.Visibility = Visibility.Collapsed;
            LessonsListBox.Visibility = Visibility.Visible;
            TestsListBox.Visibility = Visibility.Visible;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var lassons = (from x in db.Lesson where x.sections == 2 select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lassons;

            Course_Panel.Visibility = Visibility.Collapsed;
            LessonsListBox.Visibility = Visibility.Visible;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            var lassons = (from x in db.Lesson where x.sections == 3 select x).ToArray();
            LessonsListBox.DisplayMemberPath = "title";
            LessonsListBox.SelectedValuePath = "ID";
            LessonsListBox.ItemsSource = lassons;

            Course_Panel.Visibility = Visibility.Collapsed;
            LessonsListBox.Visibility = Visibility.Visible;
        }

        private void LessonsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = LessonsListBox.SelectedItem as Lesson;
            var way = (from x in db.Lesson where x.ID == selected.ID select x).ToArray();
            var way1 = way[0].content_file;
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = way1,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не удалось открыть файл: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TestsListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selected = TestsListBox.SelectedItem as Tests;
            var way = (from x in db.Tests where x.ID == selected.ID select x).ToArray();
            int selectedTestId = way[0].ID;
            Test test = new Test(selectedTestId);
            test.Show();
            this.Close();
        }

        private void LoadUserResults(int usID)
        {
            using (var db = new GuideEntities())
            {
                var history = db.Results
                    .Where(r => r.ID_user == usID)
                    .Join(db.Tests, r => r.ID_test, t => t.ID,
                        (r, t) => new
                        {
                            TestTitle = t.title,
                            Score = r.result
                        })
                    .OrderByDescending(x => x.Score)
                    .ToList()
                    .Select(x => $"Вы прошли тест «{x.TestTitle}» на {x.Score} баллов.")
                    .ToList();

                FileHistoryList.ItemsSource = history;
                FileHistoryPanel.Visibility = Visibility.Visible;
            }
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {

        }

        private void AttachFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Выберите файл для прикрепления",
                Filter = "Все файлы (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    string sourceFile = openFileDialog.FileName;
                    string fileName = System.IO.Path.GetFileName(sourceFile);
                    string destinationFolder = @"C:\Lessons";

                    // Сформировать путь назначения
                    string destinationPath = System.IO.Path.Combine(destinationFolder, fileName);

                    // Скопировать файл
                    File.Copy(sourceFile, destinationPath, overwrite: true);

                    MessageBox.Show($"Файл «{fileName}» прикреплён в папку C:\\lessons", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при прикреплении файла:\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}
