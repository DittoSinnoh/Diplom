﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace GrDes_Guide
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        GuideEntities db = new GuideEntities();
        private int usID;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Registration registration = new Registration();
            registration.Show();
            this.Close();
        }

        private void TextBlock_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Recovery recovery = new Recovery();
            recovery.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var user = (from x in db.Users where x.login == LoginTextBox.Text select x).ToArray();

            try {
                if (LoginTextBox.Text.Length == 0 || PasswordBox.Password.Length == 0)
                {
                    MessageBox.Show("Поля Логин и Пароль обязательны для заполнения", "!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (LoginTextBox.Text == user[0].login)
                    {
                        if (PasswordBox.Password == user[0].password)
                        {

                            switch (user[0].role)
                            {
                                case 1:
                                    usID = user[0].ID;
                                    MessageBox.Show("Добро пожаловать, " + user[0].name, "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                                    Profile_stud student_Main = new Profile_stud(usID);
                                    student_Main.Show();
                                    break;
                                case 2:
                                    MessageBox.Show("Добро пожаловать. Вы успешно авторизовались как руководитель" + user[0].name, "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                                    break;
                                default:
                                    MessageBox.Show("Данные не обнаружены", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                                    break;
                            }

                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Вы ввели неверный пароль", "Не удалось авторизоваться!", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Вы ввели неверный логин или пароль", "Не удалось авторизоваться!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                } 
            }
            catch (SystemException ex)
            {
                MessageBox.Show($"Ошибка системы {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
